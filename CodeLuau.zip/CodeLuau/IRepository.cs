﻿namespace CodeLuau
{
	public interface IRepository
	{
		int SaveSpeaker(Speaker speaker);
	}
}

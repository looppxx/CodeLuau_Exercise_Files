﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace CodeLuau
{
	/// <summary>
	/// Represents a single speaker
	/// </summary>
	public class Speaker
	{
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Email { get; set; }
		public int? Exp { get; set; }
		public bool HasBlog { get; set; }
		public string BlogURL { get; set; }
		public WebBrowser Browser { get; set; }
		public List<string> Certifications { get; set; }
		public string Employer { get; set; }
		public int RegistrationFee { get; set; }
		public List<Session> Sessions { get; set; }

		/// <summary>
		/// Register a speaker
		/// </summary>
		/// <returns>speakerID</returns>
		public RegisterResponse Register(IRepository repository)
		{
			// lets init some vars
			int? speakerId = null;
			bool good = false;
			bool appr = false;

			

			
						//put list of employers in array
						var emps = new List<string>() { "Pluralsight", "Microsoft", "Google" };

				
					

						if (good)
						{
							if (Sessions.Count() != 0)
							{
								foreach (var session in Sessions)
								{
									foreach (var tech in ot)
									{
										if (session.Title.Contains(tech) || session.Description.Contains(tech))
										{
											session.Approved = false;
											break;
										}
										else
										{
											session.Approved = true;
											appr = true;
										}
									}
								}
							}
							else
							{
								return new RegisterResponse(RegisterError.NoSessionsProvided);
							}

							if (appr)
							{
								

								//Now, save the speaker and sessions to the db.
								try
								{
									speakerId = repository.SaveSpeaker(this);
								}
								catch (Exception e)
								{
									//in case the db call fails 
								}
							}
							else
							{
								return new RegisterResponse(RegisterError.NoSessionsApproved);
							}
						}
						else
						{
							return new RegisterResponse(RegisterError.SpeakerDoesNotMeetStandards);
						}
			

			
		}
	}
}
using System;
using System.Collections.Generic;
using System.Linq;

namespace CodeLuau
{
    public class Speaker
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int? YearExp { get; set; }
        public bool HasBlog { get; set; }
        public string BlogURL { get; set; }
        public WebBrowser Browser { get; set; }
        public List<string> Certifications { get; set; }
        public string Employer { get; set; }
        public int RegistrationFee { get; set; }
        public List<Session> Sessions { get; set; }

        public RegisterResponse Register(IRepository repository)
        {
            if (RegistrationIsInvalid() != null) return new RegisterResponse(RegistrationIsInvalid());
            int speakerId = repository.SaveSpeaker(this);
            return new RegisterResponse((int)speakerId);
        }

        private RegisterError? RegistrationIsInvalid(){
            if (ValidateData() != null) return ValidateData();
            if (!IsEmailValid()) return RegisterError.InvalidEmail;
            if (ApproveSessions() != null) return RegisterError.NoSessionsProvided;
            if (!IsApprovedSpeaker()) return RegisterError.SpeakerDoesNotMeetStandards;
            return null;
        }

        private RegisterError? ValidateData()
        {
            if (string.IsNullOrWhiteSpace(FirstName)) return RegisterError.FirstNameRequired;
            if (string.IsNullOrWhiteSpace(LastName)) return RegisterError.LastNameRequired;
            if (string.IsNullOrWhiteSpace(Email)) return RegisterError.EmailRequired;
            if (!Sessions.Any()) return RegisterError.NoSessionsProvided;
            return null;
        }

        private bool IsEmailValid()
        {
            string emailDomain = Email.Split('@').Last();
            var OldDomain = new List<string>() {"aol.com", "prodigy.com", "compuserve.com"};
            return (!OldDomain.Contains(emailDomain) && (!(Browser.Name == WebBrowser.BrowserName.InternetExplorer && Browser.MajorVersion < 9)));
        }

        private bool IsOldTech(Session session)
        {
            var OldTech = new List<string>() { "Cobol", "Punch Cards", "Commodore", "VBScript" };

            foreach (var tech in OldTech){
                if (session.Title.Contains(tech) || session.Description.Contains(tech)) return true;
            } return false;
        }

        public RegisterError? ApproveSessions()
        {
            return Sessions.Any(IsOldTech) ? null : RegisterError.NoSessionsProvided;
        }

        private bool IsApprovedSpeaker()
            {
                if (YearExp <= 1) RegistrationFee = 500;
                else if (YearExp >= 2 && YearExp <= 3) RegistrationFee = 250;
                else if (YearExp >= 4 && YearExp <= 5) RegistrationFee = 100;
                else if (YearExp >= 6 && YearExp <= 9) RegistrationFee = 50;
                else RegistrationFee = 0;

                var ListEmployers = new List<string>() { "Pluralsight", "Microsoft", "Google" };

                return (YearExp > 10 && HasBlog && Certifications.Count() > 3 && ListEmployers.Contains(Employer));
            }
    }
}